AppealPath: DSH Hacks V2 submission files

AppealPath-one-pager.pdf   the one-page project description
AppealPath-code.pdf        every source file, with line numbers

Live app:    https://appealpath.7zhvt4rjzh.workers.dev
Demo video:  https://youtu.be/93o7D0WQdPE  (also https://appealpath.7zhvt4rjzh.workers.dev/video)
Code:        https://github.com/h6ctqtwkkg-byte/appealpath
Evaluation:  https://github.com/h6ctqtwkkg-byte/appealpath/blob/main/EVALUATION.md

A prototype, not medical or legal advice. Every letter in it is fictional.
